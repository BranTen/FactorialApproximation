/*
 * Brandon Tennyson
 * CMSC 203
 * Assignment 1
 * 1/26/2017
 * Professor: DR. Robert Alexander
 * Description:
 * This program reads an input from keyboard and stores it into a variable "n"
 * then if the integer entered is between 0-100 then it will pass through a formula
 * the formula stores the new value into the double  "s"
 * the program will then display the integer n entered and the approximate value of n
*/
package assignment1;
import java.util.Scanner;
public class FactorialApproximation 
{

	public static void main(String[] args) 
	{
	Scanner in = new Scanner(System.in);
	
	System.out.println("Please enter a whole number between 0 and 100: ");
	//read in value for "n"
	int n = in.nextInt();
	double S;
	String name;
	name = "Brandon Tennyson";
	
	//if "n" satisfies the requirements it will continue
	if (0<=n && n<=100)
		{
			//calculate the value for "n" and store the value into "S"
			S = Math.sqrt(2*Math.PI)*Math.pow(Math.E, n * -1)*Math.pow(n, n +  .5);
			//display the value
			System.out.println("The approximation of " + n + " is: " + S);
			System.out.println("\n \n Programmer: " + name);
		}
	//if "n" does not meet the requirements, this message will display
	else
		{
			System.out.println("The number entered is not between 0-100 \n"
					+ "Please reopen the program");
		}
	}

}
